<?php

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/class/class.db.theloai.php';

$db_theloai = new DB_TheLoai();
$theloai_arr = $db_theloai->get_theloai();

function e($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Thể loại | Quản trị</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1>Quản trị thể loại</h1>
        <a class="btn btn-primary" href="theloai_them.php">Thêm thể loại</a>
    </div>

    <?php if (count($theloai_arr) === 0): ?>
        <div class="alert alert-info">Không có thể loại.</div>
    <?php else: ?>
        <table class="table table-bordered table-striped" id="bang_quantri">
            <thead class="thead-dark">
            <tr>
                <th>Tên thể loại</th>
                <th>Thứ tự</th>
                <th>Ẩn/Hiện</th>
                <th colspan="2">Thao tác</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($theloai_arr as $item): ?>
                <tr>
                    <td><?= e($item['TenTL']) ?></td>
                    <td><?= e($item['ThuTu']) ?></td>
                    <td><?= (int) $item['AnHien'] === 1 ? 'Hiện' : 'Ẩn' ?></td>
                    <td><a class="btn btn-sm btn-warning" href="sua_theloai.php?id=<?= (int) $item['idTL'] ?>">Sửa</a></td>
                    <td>
                        <a class="btn btn-sm btn-danger"
                           href="delete.php?id=<?= (int) $item['idTL'] ?>"
                           onclick="return confirm('Bạn có thực sự muốn xóa?');">Xóa</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
</body>
</html>

