<?php

class DB
{
    /** @var mysqli */
    protected $link;

    public function __construct()
    {
        global $config;

        $this->link = mysqli_connect(
            $config['host'],
            $config['user'],
            $config['pass'],
            $config['data']
        );

        if (!$this->link) {
            die('Không thể kết nối cơ sở dữ liệu: ' . mysqli_connect_error());
        }

        mysqli_set_charset($this->link, 'utf8mb4');
    }

    public function db_query($query)
    {
        return mysqli_query($this->link, $query);
    }

    public function db_fetch($result)
    {
        return mysqli_fetch_assoc($result);
    }

    public function db_escape($value)
    {
        return mysqli_real_escape_string($this->link, $value);
    }
}

