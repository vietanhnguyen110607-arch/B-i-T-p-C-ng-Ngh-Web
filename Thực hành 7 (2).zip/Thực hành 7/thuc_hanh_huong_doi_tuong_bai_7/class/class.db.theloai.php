<?php

require_once __DIR__ . '/class.db.php';

class DB_TheLoai extends DB
{
    public function __construct()
    {
        parent::__construct();
    }

    /** Lấy danh sách thể loại hoặc một thể loại theo id. */
    public function get_theloai($id = -1)
    {
        $query = 'SELECT * FROM theloai';

        if ((int) $id !== -1) {
            $query .= ' WHERE idTL = ' . (int) $id;
        }

        $query .= ' ORDER BY ThuTu ASC, idTL ASC';
        $result = $this->db_query($query);

        if (!$result) {
            return [];
        }

        $theloai = [];
        while ($row = $this->db_fetch($result)) {
            $theloai[] = $row;
        }

        return $theloai;
    }

    public function them_theloai($name, $sort = 0, $show = 1)
    {
        $name = $this->db_escape(trim($name));
        $sort = (int) $sort;
        $show = (int) $show === 1 ? 1 : 0;

        $query = "INSERT INTO theloai (TenTL, ThuTu, AnHien)
                  VALUES ('$name', $sort, $show)";

        return $this->db_query($query);
    }

    public function sua_theloai($id, $name, $sort, $show)
    {
        $id = (int) $id;
        $name = $this->db_escape(trim($name));
        $sort = (int) $sort;
        $show = (int) $show === 1 ? 1 : 0;

        $query = "UPDATE theloai
                  SET TenTL = '$name', ThuTu = $sort, AnHien = $show
                  WHERE idTL = $id";

        return $this->db_query($query);
    }

    public function xoa_theloai($id)
    {
        $id = (int) $id;
        return $this->db_query("DELETE FROM theloai WHERE idTL = $id");
    }
}

