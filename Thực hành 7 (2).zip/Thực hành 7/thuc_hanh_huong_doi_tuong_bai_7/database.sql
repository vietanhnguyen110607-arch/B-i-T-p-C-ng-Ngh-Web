CREATE DATABASE IF NOT EXISTS tintuc
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE tintuc;

CREATE TABLE IF NOT EXISTS theloai (
    idTL INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    TenTL VARCHAR(255) NOT NULL,
    ThuTu INT NOT NULL DEFAULT 0,
    AnHien TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO theloai (TenTL, ThuTu, AnHien) VALUES
('Thể thao', 1, 1),
('Công nghệ', 2, 1),
('Giải trí', 3, 1);

