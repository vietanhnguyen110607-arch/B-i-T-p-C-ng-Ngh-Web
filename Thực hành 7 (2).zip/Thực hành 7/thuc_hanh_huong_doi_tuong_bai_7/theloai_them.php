<?php

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/class/class.db.theloai.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ten_theloai = trim($_POST['ten_theloai'] ?? '');
    $thu_tu = (int) ($_POST['thu_tu'] ?? 0);
    $an_hien = (int) ($_POST['an_hien'] ?? 1);

    if ($ten_theloai === '') {
        $error = 'Vui lòng nhập tên thể loại.';
    } else {
        $db_theloai = new DB_TheLoai();
        $result = $db_theloai->them_theloai($ten_theloai, $thu_tu, $an_hien);

        if ($result) {
            echo '<script>alert("Thêm thành công!"); window.location="theloai.php";</script>';
            exit;
        }

        $error = 'Thêm không thành công.';
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Thêm thể loại | Quản trị</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
<div class="container py-4">
    <h1>Thêm thể loại</h1>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endif; ?>

    <form method="post">
        <div class="form-group">
            <label for="ten_theloai">Tên thể loại</label>
            <input class="form-control" id="ten_theloai" name="ten_theloai" type="text" required
                   value="<?= htmlspecialchars($_POST['ten_theloai'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
        </div>
        <div class="form-group">
            <label for="thu_tu">Thứ tự</label>
            <input class="form-control" id="thu_tu" name="thu_tu" type="number"
                   value="<?= (int) ($_POST['thu_tu'] ?? 0) ?>">
        </div>
        <div class="form-group">
            <label for="an_hien">Ẩn/Hiện</label>
            <select class="form-control" id="an_hien" name="an_hien">
                <option value="1">Hiện</option>
                <option value="0">Ẩn</option>
            </select>
        </div>
        <button class="btn btn-primary" type="submit">Thêm thể loại</button>
        <a class="btn btn-secondary" href="theloai.php">Quay lại</a>
    </form>
</div>
</body>
</html>

