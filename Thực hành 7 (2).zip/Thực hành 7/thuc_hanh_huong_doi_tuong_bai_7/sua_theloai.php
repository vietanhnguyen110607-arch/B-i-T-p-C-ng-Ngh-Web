<?php

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/class/class.db.theloai.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id || $id < 1) {
    header('Location: theloai.php');
    exit;
}

$db_theloai = new DB_TheLoai();
$theloai_arr = $db_theloai->get_theloai($id);

if (count($theloai_arr) === 0) {
    header('Location: theloai.php');
    exit;
}

$ten_theloai = $theloai_arr[0]['TenTL'];
$thu_tu = $theloai_arr[0]['ThuTu'];
$an_hien = $theloai_arr[0]['AnHien'];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ten_theloai = trim($_POST['ten_theloai'] ?? '');
    $thu_tu = (int) ($_POST['thu_tu'] ?? 0);
    $an_hien = (int) ($_POST['an_hien'] ?? 1);

    if ($ten_theloai === '') {
        $error = 'Vui lòng nhập tên thể loại.';
    } else {
        $result = $db_theloai->sua_theloai($id, $ten_theloai, $thu_tu, $an_hien);

        if ($result) {
            echo '<script>alert("Cập nhật thành công!"); window.location="theloai.php";</script>';
            exit;
        }

        $error = 'Cập nhật không thành công.';
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cập nhật thể loại | Quản trị</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
<div class="container py-4">
    <h1>Cập nhật thể loại</h1>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endif; ?>

    <form method="post">
        <div class="form-group">
            <label for="ten_theloai">Tên thể loại</label>
            <input class="form-control" id="ten_theloai" name="ten_theloai" type="text" required
                   value="<?= htmlspecialchars($ten_theloai, ENT_QUOTES, 'UTF-8') ?>">
        </div>
        <div class="form-group">
            <label for="thu_tu">Thứ tự</label>
            <input class="form-control" id="thu_tu" name="thu_tu" type="number" value="<?= (int) $thu_tu ?>">
        </div>
        <div class="form-group">
            <label for="an_hien">Ẩn/Hiện</label>
            <select class="form-control" id="an_hien" name="an_hien">
                <option value="1" <?= (int) $an_hien === 1 ? 'selected' : '' ?>>Hiện</option>
                <option value="0" <?= (int) $an_hien === 0 ? 'selected' : '' ?>>Ẩn</option>
            </select>
        </div>
        <button class="btn btn-primary" type="submit">Cập nhật thể loại</button>
        <a class="btn btn-secondary" href="theloai.php">Quay lại</a>
    </form>
</div>
</body>
</html>

