<?php

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/class/class.db.theloai.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    echo '<script>alert("Mã thể loại không hợp lệ!"); window.location="theloai.php";</script>';
    exit;
}

$db_theloai = new DB_TheLoai();
$result = $db_theloai->xoa_theloai($id);

if ($result) {
    echo '<script>alert("Xóa thành công!"); window.location="theloai.php";</script>';
} else {
    echo '<script>alert("Xóa không thành công!"); window.location="theloai.php";</script>';
}

