<?php
$exercise = 3;
require __DIR__ . '/handler.php';
