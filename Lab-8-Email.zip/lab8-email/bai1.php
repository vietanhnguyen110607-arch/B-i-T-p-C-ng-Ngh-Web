<?php
$exercise = 1;
require __DIR__ . '/handler.php';
