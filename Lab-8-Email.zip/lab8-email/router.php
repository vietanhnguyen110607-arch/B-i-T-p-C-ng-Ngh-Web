<?php
// Chỉ cho phép truy cập các entry point công khai của ứng dụng.
$path = rawurldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?? '/');
$routes = ['/' => 'index.php', '/index.php' => 'index.php', '/bai1.php' => 'bai1.php', '/mail.php' => 'mail.php', '/bai3.php' => 'bai3.php', '/download.php' => 'download.php'];
if ($path === '/style.css') {
    header('Content-Type: text/css; charset=utf-8');
    readfile(__DIR__ . '/style.css');
} elseif (isset($routes[$path])) {
    require __DIR__ . '/' . $routes[$path];
} else {
    http_response_code(404);
    echo 'Không tìm thấy trang.';
}
