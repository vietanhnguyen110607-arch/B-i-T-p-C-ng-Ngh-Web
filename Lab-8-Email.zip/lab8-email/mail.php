<?php
$exercise = 2;
require __DIR__ . '/handler.php';
