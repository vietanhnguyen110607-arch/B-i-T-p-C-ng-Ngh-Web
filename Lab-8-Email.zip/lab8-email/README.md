# Lời giải Lab 8. Email

Nhấp đúp `CHAY-BAI.cmd` hoặc `CHAY-LAB8.cmd` ở thư mục cha, rồi mở http://127.0.0.1:8008/.
Yêu cầu: PHP XAMPP tại `C:\xampp\php\php.exe`. Không cần bật Apache hoặc MySQL.

Mặc định ứng dụng chạy thử: PHPMailer tạo email MIME thật và lưu `.eml` trong `storage/outbox`.
Giao diện có nút tải thư. Chế độ này không kết nối SMTP và không gửi ra internet.

## Các bài

1. `bai1.php`: gửi tới địa chỉ cố định trong `fixed_to`, tiêu đề và nội dung cố định, kèm `loi-chao.txt`.
2. `index.php` và `mail.php`: biểu mẫu POST với email, tiêu đề, nội dung, tệp đính kèm tùy chọn tối đa 5 MB. Dùng đúng các tên trường của đề: `email`, `tieude`, `content`, `file`.
3. `bai3.php`: tách danh sách địa chỉ bằng dấu phẩy, chấm phẩy hoặc khoảng trắng; kiểm tra hợp lệ và loại trùng. Có thể chọn lấy địa chỉ từ bảng `contacts` của SQLite (SQL), được tạo và thêm ba địa chỉ mẫu tự động, không xóa dữ liệu cũ. Các địa chỉ nằm trong To nên người nhận có thể nhìn thấy nhau như ví dụ trong đề.

Logic chung trong `bootstrap.php`; tiếp nhận POST, CSRF và tệp tải lên trong `handler.php`.
Nội dung biểu mẫu là văn bản, được escape trước khi đặt trong thân HTML; có cả bản plain text.
PHPMailer 7.1.1 lấy từ https://github.com/PHPMailer/PHPMailer/releases/tag/v7.1.1, kèm giấy phép LGPL tại `vendor/PHPMailer/LICENSE`.

## Gửi thật qua Gmail

1. Bật xác minh hai bước và tạo mật khẩu ứng dụng: https://support.google.com/accounts/answer/185833.
2. Sao chép `config.local.example.php` thành `config.local.php`.
3. Điền `username`, `password`, `from_email`, `from_name`, `fixed_to` của bạn. Dùng mật khẩu ứng dụng, không dùng mật khẩu đăng nhập Gmail. Giữ tệp này trên máy, không gửi vào chat.
4. Đặt `transport` là `smtp` (đã có trong mẫu). Cấu hình mặc định `smtp.gmail.com`, STARTTLS, cổng 587. Nếu dùng 465 thì đặt `encryption` là `ssl` và `port` là 465.
5. Tải lại trang, kiểm tra người nhận rồi bấm Gửi. Kiểm tra hộp thư đến và thư rác. SMTP chấp nhận thư không đồng nghĩa thư chắc chắn đã vào inbox.

Không dùng tài khoản, mật khẩu và người nhận mẫu trong PDF. Phần bật “ứng dụng kém an toàn” trong tài liệu đã cũ; dùng hướng dẫn Google ở trên. Giữ xác minh chứng chỉ TLS; không sao chép phần `verify_peer=false` trong đề.

## Chạy thủ công và kiểm tra

```powershell
& C:\xampp\php\php.exe -d upload_max_filesize=5M -d post_max_size=8M -S 127.0.0.1:8008 -t . router.php
```

Chạy tại thư mục `lab8-email`. Router giới hạn các tệp có thể truy cập từ trình duyệt.
Không dùng Live Server cho PHP. Các tệp `.eml` chứa nội dung và đính kèm; xóa thủ công nếu không cần giữ.

Sau khi server chạy:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tests\smoke.ps1
```

Bộ kiểm tra chỉ chạy khi ứng dụng ở chế độ preview, không gửi email thật.
