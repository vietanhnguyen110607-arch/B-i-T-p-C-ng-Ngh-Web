<?php
$name = $_GET['file'] ?? '';
if (!is_string($name) || !preg_match('/^\d{8}-\d{6}-[a-f0-9]{10}\.eml$/D', $name)) {
    http_response_code(404);
    exit('Không tìm thấy thư.');
}
$path = __DIR__ . '/storage/outbox/' . $name;
if (!is_file($path)) {
    http_response_code(404);
    exit('Không tìm thấy thư.');
}
header('Content-Type: message/rfc822');
header('Content-Disposition: attachment; filename="' . $name . '"');
header('X-Content-Type-Options: nosniff');
readfile($path);
