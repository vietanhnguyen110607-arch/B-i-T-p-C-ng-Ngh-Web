<?php
require __DIR__ . '/bootstrap.php';
session_start();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    exit('Hãy gửi bằng biểu mẫu trên trang chủ.');
}
if (!is_string($_POST['csrf'] ?? null) || !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf']) || empty($_SESSION['csrf'])) {
    http_response_code(403);
    exit('Phiên làm việc không hợp lệ. Hãy mở lại trang chủ.');
}
try {
    $config = require __DIR__ . '/config.php';
    $attachment = null;
    if ($exercise === 1) {
        $addresses = recipients($config['fixed_to']);
        $subject = 'Gửi thư từ PHP';
        $content = 'Chào bạn! Chúc an lành!';
        $attachment = ['path' => __DIR__ . '/loi-chao.txt', 'name' => 'loi-chao.txt'];
    } else {
        $addresses = $exercise === 2 ? recipients((string) ($_POST['email'] ?? '')) :
            (!empty($_POST['from_database']) ? databaseRecipients() : recipients((string) ($_POST['emails'] ?? '')));
        if ($exercise === 2 && count($addresses) !== 1) {
            throw new InvalidArgumentException('Bài 2 chỉ nhận một địa chỉ email.');
        }
        $subject = (string) ($_POST['tieude'] ?? '');
        $content = (string) ($_POST['content'] ?? '');
        $upload = $_FILES['file'] ?? null;
        if ($exercise === 2 && $upload && $upload['error'] !== UPLOAD_ERR_NO_FILE) {
            if ($upload['error'] !== UPLOAD_ERR_OK) {
                throw new InvalidArgumentException('Tải tệp thất bại hoặc vượt giới hạn dung lượng PHP.');
            }
            if ($upload['size'] > 5 * 1024 * 1024 || !is_uploaded_file($upload['tmp_name'])) {
                throw new InvalidArgumentException('Tệp đính kèm phải hợp lệ và không quá 5 MB.');
            }
            // PHP tự xóa tệp tải lên sau request; không lưu tệp thực thi vào webroot.
            $attachment = ['path' => $upload['tmp_name'], 'name' => basename(str_replace('\\', '/', $upload['name']))];
        }
    }
    $result = deliver($config, $addresses, $subject, $content, $attachment);
    $_SESSION['flash'] = ['ok' => true, 'text' => $result['mode'] === 'preview'
        ? 'Bài ' . $exercise . ': Đã tạo thư chạy thử cho ' . $result['count'] . ' địa chỉ. Chưa gửi email thật.'
        : 'Bài ' . $exercise . ': SMTP đã chấp nhận thư gửi tới ' . $result['count'] . ' địa chỉ.', 'file' => $result['file']];
} catch (Throwable $error) {
    $_SESSION['flash'] = ['ok' => false, 'text' => 'Không gửi được: ' . $error->getMessage()];
}
header('Location: index.php', true, 303);
exit;
