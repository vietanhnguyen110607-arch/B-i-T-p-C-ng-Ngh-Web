<?php
require __DIR__ . '/bootstrap.php';
session_start();
$config = require __DIR__ . '/config.php';
$_SESSION['csrf'] ??= bin2hex(random_bytes(32));
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);
$contacts = databaseRecipients();
$files = glob(__DIR__ . '/storage/outbox/*.eml');
rsort($files);
?>
<!doctype html>
<html lang="vi">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Lab 8 - Email</title><link rel="stylesheet" href="style.css"></head>
<body><main>
<header><span class="tag">PHP · PHPMailer · SMTP</span><h1>Lab 8. Gửi Email</h1><p>Ba bài thực hành gửi thư, đính kèm tệp và lấy người nhận từ SQL.</p></header>
<div class="notice"><strong><?= $config['transport'] === 'preview' ? 'Chế độ chạy thử' : 'Chế độ SMTP' ?></strong> — <?= $config['transport'] === 'preview' ? 'Thư được lưu thành tệp .eml trên máy, chưa gửi ra hộp thư thật.' : 'Bấm Gửi sẽ gửi thư thật tới các địa chỉ đã chọn.' ?></div>
<?php if ($flash): ?><div class="notice <?= $flash['ok'] ? 'success' : 'error' ?>" role="status"><?= h($flash['text']) ?><?php if (!empty($flash['file'])): ?> <a href="download.php?file=<?= h($flash['file']) ?>">Tải thư .eml</a><?php endif ?></div><?php endif ?>
<div class="grid">
<section><span class="number">01</span><h2>Gửi thư cố định</h2><p>Người nhận: <strong><?= h($config['fixed_to']) ?></strong></p><p>Tiêu đề: Gửi thư từ PHP<br>Nội dung: Chào bạn! Chúc an lành!</p><p>Đính kèm: loi-chao.txt</p>
<form action="bai1.php" method="post"><input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>"><button>Gửi bài 1</button></form></section>
<section><span class="number">02</span><h2>Soạn thư & đính kèm</h2>
<form action="mail.php" enctype="multipart/form-data" method="post">
<input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>">
<label>Email người nhận<input type="email" name="email" required placeholder="ban@example.com"></label>
<label>Tiêu đề<input name="tieude" required maxlength="200" placeholder="Gửi thư từ PHP"></label>
<label>Nội dung<textarea name="content" required rows="5" placeholder="Nhập lời nhắn của bạn..."></textarea></label>
<label>Tệp đính kèm (tối đa 5 MB)<input type="file" name="file"></label><button>Gửi bài 2</button></form></section>
<section><span class="number">03</span><h2>Gửi nhiều địa chỉ</h2>
<form action="bai3.php" method="post"><input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>">
<label>Danh sách email<textarea name="emails" rows="3">an@example.com, binh@example.com, an@example.com</textarea></label><small>Phân cách bằng dấu phẩy, chấm phẩy hoặc xuống dòng. Tự loại địa chỉ trùng.</small>
<label class="check"><input type="checkbox" name="from_database" value="1"> Lấy danh sách từ cơ sở dữ liệu SQL</label><small>SQLite: <?= h(implode(', ', $contacts)) ?></small>
<label>Tiêu đề<input name="tieude" value="Thông báo từ Lab 8" required maxlength="200"></label>
<label>Nội dung<textarea name="content" rows="4" required>Chào các bạn! Đây là email gửi cho nhiều địa chỉ.</textarea></label><button>Gửi bài 3</button></form></section>
</div>
<section class="history"><h2>Thư chạy thử đã tạo <span class="tag"><?= count($files) ?></span></h2><p>Tải tệp .eml và mở bằng ứng dụng email để xem nội dung cùng tệp đính kèm.</p>
<?php if (!$files): ?><p>Chưa có thư. Bấm một nút gửi ở trên để chạy thử.</p><?php endif ?>
<?php foreach (array_slice($files, 0, 15) as $file): ?><a class="file" href="download.php?file=<?= h(basename($file)) ?>"><?= h(basename($file)) ?> ↓</a><?php endforeach ?></section>
<footer>Muốn gửi Gmail thật: xem README.md và điền config.local.php trên máy của bạn.</footer>
</main></body></html>
