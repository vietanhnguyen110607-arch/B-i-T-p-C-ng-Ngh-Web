﻿$ErrorActionPreference = 'Stop'
$base = 'http://127.0.0.1:8008'
function Assert($condition, $message) { if (-not $condition) { throw $message }; Write-Host "PASS: $message" }
$homePage = Invoke-WebRequest "$base/" -UseBasicParsing -SessionVariable session
Assert ($homePage.Content.Contains('Chế độ chạy thử')) 'Preview mode required'
$token = [regex]::Match($homePage.Content, 'name="csrf" value="([a-f0-9]+)"').Groups[1].Value
Assert ($token.Length -eq 64) 'CSRF token present'
function Post-Form($route, $fields) {
    return Invoke-WebRequest "$base/$route" -UseBasicParsing -WebSession $session -Method Post -Body $fields
}
$one = Post-Form 'bai1.php' @{csrf=$token}
Assert ($one.Content.Contains('Bài 1: Đã tạo thư chạy thử cho 1')) 'Exercise 1 generated MIME'
$filename = [regex]::Match($one.Content, 'download.php\?file=([\w.-]+)').Groups[1].Value
$mime = (Invoke-WebRequest "$base/download.php?file=$filename" -UseBasicParsing).Content
if ($mime -is [byte[]]) { $mime = [Text.Encoding]::UTF8.GetString($mime) }
Assert ($mime.Contains('loi-chao.txt') -and $mime.Contains('multipart/mixed')) 'Exercise 1 attachment in MIME'
$two = Post-Form 'mail.php' @{csrf=$token; email='student@example.com'; tieude='Test UTF-8'; content='Xin chào!'}
Assert ($two.Content.Contains('Bài 2: Đã tạo thư chạy thử cho 1')) 'Exercise 2 without attachment'
$three = Post-Form 'bai3.php' @{csrf=$token; emails='a@example.com,b@example.com,A@example.com'; tieude='Test'; content='Hello'}
Assert ($three.Content.Contains('Bài 3: Đã tạo thư chạy thử cho 2')) 'Exercise 3 deduplicates recipients'
$sql = Post-Form 'bai3.php' @{csrf=$token; from_database='1'; tieude='SQL'; content='Hello SQL'}
Assert ($sql.Content.Contains('Bài 3: Đã tạo thư chạy thử cho 3')) 'Exercise 3 reads SQL contacts'
$invalid = Post-Form 'mail.php' @{csrf=$token; email='invalid-email'; tieude='Test'; content='Hello'}
Assert ($invalid.Content.Contains('Email không hợp lệ')) 'Invalid email rejected'
$empty = Post-Form 'mail.php' @{csrf=$token; email='a@example.com'; tieude=''; content='Hello'}
Assert ($empty.Content.Contains('không được để trống')) 'Empty subject rejected'
foreach ($route in @('config.local.example.php','storage/contacts.sqlite','tests/smoke.ps1','mail.php')) {
    try { Invoke-WebRequest "$base/$route" -UseBasicParsing | Out-Null; throw "Unexpected success: $route" }
    catch { $status = [int]$_.Exception.Response.StatusCode; Assert ($status -in @(404,405)) "Private route or GET rejected: $route" }
}
try { Post-Form 'bai1.php' @{csrf='wrong'} | Out-Null; throw 'Bad CSRF accepted' }
catch { Assert ([int]$_.Exception.Response.StatusCode -eq 403) 'Invalid CSRF rejected' }
Write-Host 'All smoke checks passed.' -ForegroundColor Green
