<?php
// Sao chép config.local.example.php thành config.local.php để gửi thật.
$config = [
    'transport' => 'preview',
    'host' => 'smtp.gmail.com',
    'port' => 587,
    'encryption' => 'tls',
    'username' => '',
    'password' => '',
    'from_email' => 'student@example.com',
    'from_name' => 'Sinh viên - Lab 8',
    'fixed_to' => 'recipient@example.com',
];
if (is_file(__DIR__ . '/config.local.php')) {
    $config = array_replace($config, require __DIR__ . '/config.local.php');
}
return $config;
