param([switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
$php = 'C:\xampp\php\php.exe'
$url = 'http://127.0.0.1:8008/'
function Test-App {
    try { return (Invoke-WebRequest $url -UseBasicParsing -TimeoutSec 2).Content.Contains('<title>Lab 8 - Email</title>') }
    catch { return $false }
}
try {
    if (-not (Test-Path -LiteralPath $php)) { throw 'Khong tim thay PHP XAMPP: C:\xampp\php\php.exe' }
    if (-not (Test-App)) {
        $listener = New-Object System.Net.Sockets.TcpClient
        try { $listener.Connect('127.0.0.1', 8008); $busy = $true } catch { $busy = $false } finally { $listener.Dispose() }
        if ($busy) { throw 'Cong 8008 dang duoc ung dung khac su dung.' }
        $uploadDirectory = Join-Path $PSScriptRoot 'storage\uploads'
        New-Item -ItemType Directory -Force -Path $uploadDirectory | Out-Null
        $arguments = '-d upload_max_filesize=5M -d post_max_size=8M -d "upload_tmp_dir=' + $uploadDirectory + '" -S 127.0.0.1:8008 -t "' + $PSScriptRoot + '" "' + (Join-Path $PSScriptRoot 'router.php') + '"'
        Start-Process -FilePath $php -ArgumentList $arguments -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $PSScriptRoot 'server.log') -RedirectStandardError (Join-Path $PSScriptRoot 'server-error.log')
        for ($attempt = 0; $attempt -lt 20; $attempt++) {
            if (Test-App) { break }
            Start-Sleep -Milliseconds 300
        }
        if (-not (Test-App)) { throw 'PHP chua san sang. Xem server-error.log.' }
    }
    Write-Host "Lab 8 da san sang: $url" -ForegroundColor Green
    if (-not $NoBrowser) { Start-Process $url }
} catch { Write-Host $_.Exception.Message -ForegroundColor Red; exit 1 }
