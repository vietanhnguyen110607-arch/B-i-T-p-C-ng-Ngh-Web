<?php
return [
    'transport' => 'smtp',
    'username' => 'your-name@gmail.com',
    'password' => 'YOUR_16_CHARACTER_APP_PASSWORD',
    'from_email' => 'your-name@gmail.com',
    'from_name' => 'Tên của bạn',
    'fixed_to' => 'recipient@example.com',
];
