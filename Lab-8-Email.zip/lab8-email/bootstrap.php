<?php
declare(strict_types=1);

use PHPMailer\PHPMailer\PHPMailer;

require_once __DIR__ . '/vendor/PHPMailer/src/Exception.php';
require_once __DIR__ . '/vendor/PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/vendor/PHPMailer/src/SMTP.php';

date_default_timezone_set('Asia/Bangkok');
if (PHP_SAPI !== 'cli') {
    $sessionDirectory = __DIR__ . '/storage/sessions';
    if (!is_dir($sessionDirectory)) {
        mkdir($sessionDirectory, 0700, true);
    }
    session_save_path($sessionDirectory);
    ini_set('session.cookie_httponly', '1');
    ini_set('session.cookie_samesite', 'Lax');
}

function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function recipients(string $input): array
{
    $addresses = preg_split('/[;,\s]+/', trim($input), -1, PREG_SPLIT_NO_EMPTY);
    if (!$addresses) {
        throw new InvalidArgumentException('Hãy nhập ít nhất một địa chỉ email.');
    }
    $result = [];
    foreach ($addresses as $address) {
        if (!filter_var($address, FILTER_VALIDATE_EMAIL)) {
            throw new InvalidArgumentException('Email không hợp lệ: ' . $address);
        }
        $result[strtolower($address)] = $address;
    }
    if (count($result) > 50) {
        throw new InvalidArgumentException('Mỗi lần gửi tối đa 50 địa chỉ.');
    }
    return array_values($result);
}

function databaseRecipients(): array
{
    // SQLite là SQL tích hợp sẵn trong PHP; không cần khởi động MySQL.
    $db = new PDO('sqlite:' . __DIR__ . '/storage/contacts.sqlite');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->exec('CREATE TABLE IF NOT EXISTS contacts (id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE)');
    $insert = $db->prepare('INSERT OR IGNORE INTO contacts(name, email) VALUES (?, ?)');
    foreach ([['An', 'an@example.com'], ['Bình', 'binh@example.com'], ['Chi', 'chi@example.com']] as $contact) {
        $insert->execute($contact);
    }
    return $db->query('SELECT email FROM contacts ORDER BY id')->fetchAll(PDO::FETCH_COLUMN);
}

function deliver(array $config, array $addresses, string $subject, string $content, ?array $attachment = null): array
{
    if (trim($subject) === '' || trim($content) === '') {
        throw new InvalidArgumentException('Tiêu đề và nội dung không được để trống.');
    }
    if (preg_match('/[\r\n]/', $subject) || mb_strlen($subject) > 200) {
        throw new InvalidArgumentException('Tiêu đề tối đa 200 ký tự và chỉ có một dòng.');
    }
    $addresses = recipients(implode(',', $addresses));
    $mail = new PHPMailer(true);
    $mail->CharSet = 'UTF-8';
    $mail->setFrom($config['from_email'], $config['from_name']);
    foreach ($addresses as $address) {
        $mail->addAddress($address);
    }
    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body = '<h2>Xin chào bạn!</h2><div>' . nl2br(h($content)) . '</div>';
    $mail->AltBody = "Xin chào bạn!\n\n" . $content;
    if ($attachment !== null) {
        $mail->addAttachment($attachment['path'], $attachment['name']);
    }
    if ($config['transport'] === 'preview') {
        // PHPMailer tạo MIME thật, bao gồm UTF-8, HTML và attachment.
        $mail->preSend();
        $filename = date('Ymd-His') . '-' . bin2hex(random_bytes(5)) . '.eml';
        if (file_put_contents(__DIR__ . '/storage/outbox/' . $filename, $mail->getSentMIMEMessage(), LOCK_EX) === false) {
            throw new RuntimeException('Không ghi được thư xem thử.');
        }
        return ['mode' => 'preview', 'file' => $filename, 'count' => count($addresses)];
    }
    if ($config['transport'] !== 'smtp') {
        throw new RuntimeException('Cấu hình transport phải là preview hoặc smtp.');
    }
    if ($config['username'] === '' || $config['password'] === '') {
        throw new RuntimeException('Chưa cấu hình Gmail và mật khẩu ứng dụng trong config.local.php.');
    }
    $mail->isSMTP();
    $mail->Host = $config['host'];
    $mail->SMTPAuth = true;
    $mail->Username = $config['username'];
    $mail->Password = str_replace(' ', '', $config['password']);
    $mail->SMTPSecure = $config['encryption'];
    $mail->Port = (int) $config['port'];
    $mail->Timeout = 20;
    // Giữ nguyên kiểm tra chứng chỉ TLS mặc định của PHPMailer.
    $mail->send();
    return ['mode' => 'smtp', 'file' => null, 'count' => count($addresses)];
}
