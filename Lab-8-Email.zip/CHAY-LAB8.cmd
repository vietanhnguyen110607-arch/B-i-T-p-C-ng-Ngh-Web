@echo off
call "%~dp0lab8-email\CHAY-BAI.cmd"
