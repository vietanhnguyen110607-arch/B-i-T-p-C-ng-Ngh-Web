<?php
declare(strict_types=1);
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/product_db.php';

function h($value): string {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}
$statement = $db->prepare('SELECT categoryID FROM categories WHERE categoryName = :name');
$statement->execute(['name' => 'Guitars']);
$category_id = $statement->fetchColumn();
if ($category_id === false) {
    exit('Không tìm thấy danh mục Guitars.');
}
$category_id = (int) $category_id;
$message = '';
// Dữ liệu minh họa: thay bằng dữ liệu trong index.php gốc nếu có.
$code = 'guitar_demo';
$name = 'Demo Guitar';
$price = 299.00;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $rows = add_product($category_id, $code, $name, $price);
        $message = $rows === 1 ? 'Thêm sản phẩm thành công.' : 'Không thêm được sản phẩm.';
    } catch (PDOException $e) {
        if ((int) ($e->errorInfo[1] ?? 0) === 1062) {
            $message = 'Không thể thêm: mã sản phẩm đã tồn tại.';
        } else {
            error_log($e->getMessage());
            $message = 'Có lỗi khi thêm sản phẩm.';
        }
    }
}
$products = get_products_by_category($category_id);
?>
<!doctype html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Exercise 19-1 — Guitars</title>
    <style>
        body { font-family: system-ui, sans-serif; max-width: 850px; margin: 50px auto; padding: 0 20px; background: #f4f6fa; color: #17223b; }
        main { background: white; padding: 28px; border-radius: 14px; }
        table { width: 100%; border-collapse: collapse; margin: 24px 0; }
        th, td { text-align: left; padding: 12px; border-bottom: 1px solid #ddd; }
        button { background: #234bd1; color: white; border: 0; padding: 12px 18px; border-radius: 6px; cursor: pointer; }
        .message { padding: 14px; background: #e9efff; }
    </style>
</head>
<body><main>
    <p>Exercise 19-1 · PHP / PDO / MySQL</p>
    <h1>Danh mục Guitars</h1>
    <?php if ($message !== ''): ?><p class="message" role="status"><?= h($message) ?></p><?php endif; ?>
    <table>
        <thead><tr><th>Mã sản phẩm</th><th>Tên sản phẩm</th><th>Giá (USD)</th></tr></thead>
        <tbody>
        <?php foreach ($products as $product): ?>
            <tr><td><?= h($product['productCode']) ?></td><td><?= h($product['productName']) ?></td><td><?= h(number_format((float) $product['listPrice'], 2)) ?></td></tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <form method="post">
        <p>Sản phẩm mẫu: <?= h($name) ?> · <?= h($code) ?> · <?= h(number_format($price, 2)) ?> USD</p>
        <button type="submit">Thêm sản phẩm mẫu</button>
    </form>
    <p>Bấm lần đầu để thêm. Bấm lần nữa để kiểm tra thông báo trùng mã.</p>
</main></body>
</html>
