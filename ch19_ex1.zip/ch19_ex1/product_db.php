<?php
declare(strict_types=1);

function get_products_by_category(int $category_id): array {
    global $db;
    $statement = $db->prepare('SELECT * FROM products WHERE categoryID = :id ORDER BY productID');
    $statement->execute(['id' => $category_id]);
    return $statement->fetchAll();
}

function add_product(int $category_id, string $code, string $name, float $price): int {
    global $db;
    $statement = $db->prepare('INSERT INTO products (categoryID, productCode, productName, listPrice) VALUES (:category, :code, :name, :price)');
    $statement->execute(['category' => $category_id, 'code' => $code, 'name' => $name, 'price' => $price]);
    return $statement->rowCount();
}
