param([switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
$phpExecutable = 'C:\xampp\php\php.exe'
$url = 'http://127.0.0.1:8000/'
function Test-Port([int]$Port) {
    $client = New-Object System.Net.Sockets.TcpClient
    try { $client.Connect('127.0.0.1', $Port); return $true }
    catch { return $false }
    finally { $client.Dispose() }
}
function Test-Application {
    try {
        $page = Invoke-WebRequest $url -UseBasicParsing -TimeoutSec 3
        return $page.StatusCode -eq 200 -and $page.Content.Contains('Exercise 19-1') -and $page.Content.Contains('Guitars')
    } catch { return $false }
}
try {
    if (-not (Test-Path -LiteralPath $phpExecutable)) { throw 'Can cai XAMPP tai C:\xampp.' }
    if (-not (Test-Port 3306)) {
        Write-Host 'Dang bat MySQL...'
        Start-Process 'C:\xampp\mysql\bin\mysqld.exe' -ArgumentList '--defaults-file=C:\xampp\mysql\bin\my.ini','--bind-address=127.0.0.1' -WindowStyle Hidden
        for ($i = 0; $i -lt 20; $i++) {
            if (Test-Port 3306) { break }
            Start-Sleep -Milliseconds 500
        }
        if (-not (Test-Port 3306)) { throw 'MySQL khong khoi dong duoc. Xem XAMPP Control Panel.' }
    }
    & $phpExecutable (Join-Path $PSScriptRoot 'setup.php')
    if ($LASTEXITCODE -ne 0) { throw 'Khong tao duoc database. Kiem tra tai khoan MySQL trong setup.php va database.php.' }
    if (-not (Test-Application)) {
        if (Test-Port 8000) { throw 'Cong 8000 dang ban hoac trang PHP bao loi. Xem server-error.log.' }
        $serverArguments = '-S 127.0.0.1:8000 -t "' + $PSScriptRoot + '"'
        Start-Process $phpExecutable -ArgumentList $serverArguments -WindowStyle Hidden -RedirectStandardOutput (Join-Path $PSScriptRoot 'server.log') -RedirectStandardError (Join-Path $PSScriptRoot 'server-error.log')
        for ($i = 0; $i -lt 15; $i++) {
            if (Test-Application) { break }
            Start-Sleep -Milliseconds 400
        }
        if (-not (Test-Application)) { throw 'PHP chua san sang. Xem server-error.log.' }
    }
    Write-Host "Bai da san sang: $url" -ForegroundColor Green
    if (-not $NoBrowser) { Start-Process $url }
    exit 0
} catch {
    Write-Host "KHONG KHOI DONG DUOC: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
