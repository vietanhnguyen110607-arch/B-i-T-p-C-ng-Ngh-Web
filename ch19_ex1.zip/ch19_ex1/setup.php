<?php
// Run once from the terminal: C:\xampp\php\php.exe setup.php
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('Run setup.php from the terminal.');
}
$db = new PDO('mysql:host=127.0.0.1;charset=utf8mb4', 'root', '', [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
$db->exec('CREATE DATABASE IF NOT EXISTS exercise19_1 CHARACTER SET utf8mb4');
$db->exec('USE exercise19_1');
$db->exec('CREATE TABLE IF NOT EXISTS categories (
    categoryID INT PRIMARY KEY,
    categoryName VARCHAR(100) NOT NULL UNIQUE
)');
$db->exec('CREATE TABLE IF NOT EXISTS products (
    productID INT AUTO_INCREMENT PRIMARY KEY,
    categoryID INT NOT NULL,
    productCode VARCHAR(50) NOT NULL UNIQUE,
    productName VARCHAR(255) NOT NULL,
    listPrice DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (categoryID) REFERENCES categories(categoryID)
)');
$db->exec("INSERT IGNORE INTO categories VALUES (1, 'Guitars'), (2, 'Basses')");
$db->exec("INSERT IGNORE INTO products (categoryID, productCode, productName, listPrice) VALUES
    (1, 'strat', 'Fender Stratocaster', 699.00),
    (1, 'les_paul', 'Gibson Les Paul', 1199.00),
    (2, 'precision', 'Fender Precision Bass', 799.00)");
echo "Database ready.\n";
