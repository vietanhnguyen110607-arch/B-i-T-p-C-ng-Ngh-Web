<?php
declare(strict_types=1);

try {
$db = new PDO(
    'mysql:host=127.0.0.1;dbname=exercise19_1;charset=utf8mb4',
    'root',
    '',
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
     PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
);
} catch (PDOException $e) {
    error_log($e->getMessage());
    http_response_code(503);
    header('Content-Type: text/html; charset=utf-8');
    exit('<!doctype html><html lang="vi"><meta charset="utf-8"><title>Chưa kết nối được MySQL</title><h1>Chưa kết nối được cơ sở dữ liệu</h1><p>Hãy mở tệp <strong>CHAY-BAI.cmd</strong> trong thư mục bài tập để khởi động MySQL và chuẩn bị dữ liệu, rồi tải lại trang.</p></html>');
}
