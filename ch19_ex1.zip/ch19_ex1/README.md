# Exercise 19-1

## Cách chạy tự động

Nhấp đúp **CHAY-BAI.cmd** trong thư mục bài tập hoặc thư mục cha. Tệp tự bật MySQL nếu chưa chạy, chuẩn bị database và bật PHP. Trình duyệt chỉ mở sau khi trang sẵn sàng. Không cần giữ VS Code mở. Sau khi khởi động lại Windows, chạy lại tệp này.

Địa chỉ: **http://127.0.0.1:8000/**. Trang chuyển tiếp ở cổng 5500 không tự bật PHP.

Cấu hình: XAMPP tại `C:\xampp`, MySQL cổng 3306, tài khoản `root`, mật khẩu trống. Chạy lại không xóa dữ liệu. Nếu có lỗi, cửa sổ khởi động giữ thông báo để bạn đọc.

Trong VS Code, mo dung thu muc `ch19_ex1`, bam **Ctrl+Shift+B** de chay va mo trang. Cau hinh da dung PHP cua XAMPP vi lenh `php` mac dinh tren may thieu driver MySQL. Neu MySQL chua bat, mo XAMPP Control Panel va bam Start o dong MySQL.

Khong dung Live Server de chay PHP. Truy cap bang `http://127.0.0.1:8000/`.

Bài giải PHP dùng PDO và MySQL. Dữ liệu minh họa được tạo riêng trong database `exercise19_1` vì chưa có mã nguồn và dữ liệu mẫu của sách.

Chạy trong PowerShell tại thư mục này, sau khi bật MySQL trong XAMPP:

```powershell
& C:\xampp\php\php.exe setup.php
& C:\xampp\php\php.exe -S 127.0.0.1:8000 -t .
```

Mở http://127.0.0.1:8000. Danh sách chỉ hiển thị Guitars. Bấm nút thêm sản phẩm: lần đầu thành công, lần sau báo trùng mã. Hàm thêm nằm trong product_db.php.

Trang dùng POST và nút bấm để chủ động thêm sản phẩm. Thay các giá trị mẫu `$code`, `$name`, `$price` trong index.php bằng dữ liệu gốc của sách khi có.
