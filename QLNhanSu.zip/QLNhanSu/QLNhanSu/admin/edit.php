<?php require '../config.php';
$id = (int)($_GET['id'] ?? 0);
$st = $conn->prepare("SELECT * FROM Users WHERE admin_id=?");
$st->bind_param("i", $id); $st->execute();
$u = $st->get_result()->fetch_assoc();
if (!$u) { header("Location: index.php"); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['admin_email']);
    $pass  = $_POST['admin_password'] !== '' ? password_hash($_POST['admin_password'], PASSWORD_DEFAULT) : $u['admin_password'];
    $img   = upload_image('images', $u['images']);
    $up = $conn->prepare("UPDATE Users SET admin_email=?, admin_password=?, images=? WHERE admin_id=?");
    $up->bind_param("sssi", $email, $pass, $img, $id);
    $up->execute();
    header("Location: index.php?msg=updated"); exit;
}
include 'header.php'; ?>
<div class="panel mx-auto" style="max-width:520px">
  <h5 class="mb-3">Sửa người dùng #<?= $id ?></h5>
  <form method="post" enctype="multipart/form-data">
    <div class="text-center mb-3">
      <img src="<?= htmlspecialchars(img_src($u['images'], '../')) ?>" width="96" height="96"
           style="border-radius:50%;object-fit:cover"
           onerror="this.onerror=null;this.src='<?= fallback_avatar($u['admin_email']) ?>'">
    </div>
    <div class="mb-3"><label class="form-label">Email</label>
      <input type="email" name="admin_email" class="form-control" value="<?= htmlspecialchars($u['admin_email']) ?>" required></div>
    <div class="mb-3"><label class="form-label">Mật khẩu mới <small class="text-muted">(để trống nếu không đổi)</small></label>
      <input type="password" name="admin_password" class="form-control"></div>
    <div class="mb-3"><label class="form-label">Đổi ảnh đại diện</label>
      <input type="file" name="images" class="form-control" accept="image/*"></div>
    <button class="btn btn-main">Cập nhật</button>
    <a href="index.php" class="btn btn-light">Hủy</a>
  </form>
</div>
</div></body></html>
