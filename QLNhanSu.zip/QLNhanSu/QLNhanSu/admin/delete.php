<?php require '../config.php';
$id = (int)($_GET['id'] ?? 0);
$st = $conn->prepare("DELETE FROM Users WHERE admin_id=?");
$st->bind_param("i", $id); $st->execute();
header("Location: index.php?msg=deleted");
