<?php require '../config.php'; include 'header.php';
$rs = $conn->query("SELECT * FROM Users ORDER BY admin_id");
$msgs = ['added'=>'Đã thêm người dùng mới.', 'updated'=>'Đã cập nhật thông tin.', 'deleted'=>'Đã xóa người dùng.'];
$m = $_GET['msg'] ?? ''; ?>

<?php if (isset($msgs[$m])): ?>
  <div class="alert alert-success alert-dismissible fade show">✔ <?= $msgs[$m] ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
<?php endif; ?>

<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
  <div class="stat"><span class="text-muted">Tổng số người dùng</span><br><b><?= $rs->num_rows ?></b></div>
  <a href="add.php" class="btn btn-main">+ Thêm người dùng</a>
</div>

<div class="panel">
  <h5 class="mb-3">Quản lý Users</h5>
  <div class="table-responsive">
  <table class="table align-middle mb-0">
    <thead><tr><th>ID</th><th>Người dùng</th><th>Mật khẩu</th><th class="text-end">Thao tác</th></tr></thead>
    <tbody>
    <?php while ($u = $rs->fetch_assoc()): ?>
      <tr>
        <td><?= $u['admin_id'] ?></td>
        <td>
          <div class="d-flex align-items-center gap-2">
            <img class="thumb" src="<?= htmlspecialchars(img_src($u['images'], '../')) ?>"
                 onerror="this.onerror=null;this.src='<?= fallback_avatar($u['admin_email']) ?>'">
            <?= htmlspecialchars($u['admin_email']) ?>
          </div>
        </td>
        <td class="text-muted">••••••••</td>
        <td class="text-end text-nowrap">
          <a href="edit.php?id=<?= $u['admin_id'] ?>" class="btn btn-sm btn-outline-primary">Sửa</a>
          <a href="delete.php?id=<?= $u['admin_id'] ?>" class="btn btn-sm btn-outline-danger"
             onclick="return confirm('Bạn chắc chắn muốn xóa người dùng này?')">Xóa</a>
        </td>
      </tr>
    <?php endwhile; ?>
    </tbody>
  </table>
  </div>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body></html>
