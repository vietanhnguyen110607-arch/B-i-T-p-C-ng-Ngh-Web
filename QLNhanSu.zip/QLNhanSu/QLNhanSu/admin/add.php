<?php require '../config.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['admin_email']);
    $pass  = password_hash($_POST['admin_password'], PASSWORD_DEFAULT);
    $img   = upload_image('images', 'default.png');
    $st = $conn->prepare("INSERT INTO Users (admin_email, admin_password, images) VALUES (?,?,?)");
    $st->bind_param("sss", $email, $pass, $img);
    $st->execute();
    header("Location: index.php?msg=added"); exit;
}
include 'header.php'; ?>
<div class="panel mx-auto" style="max-width:520px">
  <h5 class="mb-3">Thêm người dùng</h5>
  <form method="post" enctype="multipart/form-data">
    <div class="mb-3"><label class="form-label">Email</label>
      <input type="email" name="admin_email" class="form-control" required></div>
    <div class="mb-3"><label class="form-label">Mật khẩu</label>
      <input type="password" name="admin_password" class="form-control" required></div>
    <div class="mb-3"><label class="form-label">Ảnh đại diện</label>
      <input type="file" name="images" class="form-control" accept="image/*"></div>
    <button class="btn btn-main">Lưu</button>
    <a href="index.php" class="btn btn-light">Hủy</a>
  </form>
</div>
</div></body></html>
