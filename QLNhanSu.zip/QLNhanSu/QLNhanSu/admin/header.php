<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Quản trị Users</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="../assets/style.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-custom mb-4">
  <div class="container">
    <a class="brand" href="index.php">⚙️ Admin · QLNhanSu</a>
    <a href="../index.php" class="btn btn-outline-secondary btn-sm">Xem trang người dùng</a>
  </div>
</nav>
<div class="container pb-5">
