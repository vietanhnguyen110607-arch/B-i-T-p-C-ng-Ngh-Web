<?php require 'config.php';
$rs = $conn->query("SELECT * FROM Users ORDER BY admin_id");
$total = $rs->num_rows; ?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Quản lý nhân sự</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/style.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-custom">
  <div class="container">
    <a class="brand" href="index.php">👥 QLNhanSu</a>
    <a href="admin/index.php" class="btn btn-main btn-sm">Trang quản trị</a>
  </div>
</nav>

<section class="hero text-center">
  <div class="container">
    <h1>Danh sách nhân sự</h1>
    <p>Hiện có <b><?= $total ?></b> người dùng trong hệ thống</p>
  </div>
</section>

<div class="container">
  <div class="search-box">
    <input type="text" id="search" class="form-control" placeholder="🔍 Tìm theo email...">
  </div>

  <div class="row g-4" id="list">
  <?php while ($u = $rs->fetch_assoc()): ?>
    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 item" data-email="<?= htmlspecialchars(strtolower($u['admin_email'])) ?>">
      <div class="user-card">
        <span class="id-tag">#<?= $u['admin_id'] ?></span>
        <img class="avatar" src="<?= htmlspecialchars(img_src($u['images'])) ?>" alt="avatar"
             onerror="this.onerror=null;this.src='<?= fallback_avatar($u['admin_email']) ?>'">
        <h5><?= htmlspecialchars(display_name($u['admin_email'])) ?></h5>
        <div class="mail"><?= htmlspecialchars($u['admin_email']) ?></div>
      </div>
    </div>
  <?php endwhile; ?>
  </div>
  <p id="empty" class="text-center text-muted mt-4" style="display:none">Không tìm thấy kết quả phù hợp.</p>
</div>

<div class="footer">Bài kiểm tra giữa học phần – Công nghệ và Lập trình web</div>

<script>
document.getElementById('search').addEventListener('input', function () {
  const kw = this.value.trim().toLowerCase();
  let shown = 0;
  document.querySelectorAll('.item').forEach(function (el) {
    const ok = el.dataset.email.includes(kw);
    el.style.display = ok ? '' : 'none';
    if (ok) shown++;
  });
  document.getElementById('empty').style.display = shown ? 'none' : 'block';
});
</script>
</body>
</html>
