<?php
// XAMPP của bạn: MySQL cổng 3309 (nếu dùng cổng mặc định thì đổi thành 3306)
$conn = new mysqli("127.0.0.1", "root", "", "QLNhanSu", 3306);
if ($conn->connect_error) { die("Kết nối thất bại: " . $conn->connect_error); }
$conn->set_charset("utf8mb4");

// Lưu ảnh upload, trả về tên file (giữ ảnh cũ nếu không chọn ảnh mới)
function upload_image($field, $old = '') {
    if (!empty($_FILES[$field]['name']) && $_FILES[$field]['error'] === 0) {
        $ext = strtolower(pathinfo($_FILES[$field]['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg','jpeg','png','gif','webp'])) {
            $name = time() . '_' . rand(100,999) . '.' . $ext;
            move_uploaded_file($_FILES[$field]['tmp_name'], __DIR__ . '/uploads/' . $name);
            return $name;
        }
    }
    return $old;
}

// Ảnh có thể là link (http...) hoặc tên file trong thư mục uploads
function img_src($v, $prefix = '') {
    if (preg_match('/^https?:\/\//', $v)) return $v;
    return $prefix . 'uploads/' . $v;
}

// Ảnh dự phòng khi ảnh lỗi: avatar chữ cái đầu
function fallback_avatar($email) {
    return 'https://ui-avatars.com/api/?size=300&background=4f46e5&color=fff&bold=true&name=' . urlencode($email);
}

function display_name($email) {
    return ucfirst(explode('@', $email)[0]);
}
